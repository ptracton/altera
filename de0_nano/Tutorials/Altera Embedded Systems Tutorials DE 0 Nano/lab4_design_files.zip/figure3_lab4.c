#include "nios2_ctrl_reg_macros.h"

  /* Define here the addresses of switches, lights and 7-seg displays. */

/* Code needed to implement the reset funcionality */
void the_reset (void)__attribute__((section(".reset")));
void the_reset (void)
{
	asm ("movia r2, _start");	/* Go to the start of  */
	asm ("jmp r2");		  	/*   the program.      */
}

/* Code needed to deal with exceptions */
void the_exception (void)__attribute__((section(".exceptions")));
void the_exception (void)
{
	asm ("subi sp, sp, 4");		/* Save the contents of  */ 
	asm ("stw et, (sp)");	  	/*   the et register.    */
	asm ("rdctl et, ipending");	   /* If external interrupt, */ 	
	asm ("beq et, r0, SKIP_EA_DEC"); /*   then decrement et    */ 
	asm ("subi ea, ea, 4");		   /*   by 4.                */ 
	asm ("SKIP_EA_DEC:");

   /* Insert here the code needed to save all registers except r0, et and sp. */
	
	asm ("call INT_HANDLER");

  /* Insert here the code to restore all registers except r0 and sp. */
	
	asm ("eret");		    /* Return from exception. */
}

void INT_HANDLER()
{
  /* Insert here the INT_HANDLER code, which has to check if an interrupt */
  /*   from KEY1 has occurred and in response update the displayed sum.   */
}

main()
{
  /* Insert here the code for the main program, which has to enable    */
  /*   the desired interrupts. It also has to display the current sum. */
}

