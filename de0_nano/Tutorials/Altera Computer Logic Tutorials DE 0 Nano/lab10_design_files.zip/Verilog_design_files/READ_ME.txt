The design files are for DE2 and DE2-115 boards.

For DE1, the files should be edited to account for the fact that this board has fewer switches and LEDs.